chrome.devtools.panels.create("davask web limited - chrome bookmarker",
    "img/icon16.png",
    "templates/devtools_tab.html",
    function() {
    }
);
// var appScope = angular.element('[ng-app="dwlApp"] [ng-view]').scope();

// var appZone = zone.fork(appScope.initBookmark);

// appZone.fork({
//   '+appScope.initBookmark': function () {
//     console.log('cya l8r');
//   }
// }).run(function () {
//   // do stuff
// });

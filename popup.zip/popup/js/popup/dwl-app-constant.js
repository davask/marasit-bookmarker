dwlPopup.constant('TITLE', 'davask web limited - multitask manager');
dwlPopup.constant('AUTHOR', 'david asquiedge');
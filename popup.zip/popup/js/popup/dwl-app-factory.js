// dwlPopup.factory('dwlBkFactory', ['$q', function ($q){

//     return function(){

//         var deferred = $q.defer();
//         deferred.resolve();
//         return deferred.promise;

//     }

// }]);
chrome.devtools.panels.create("davask web limited - multi task",
    "img/icon16.png",
    "templates/views/devtools_tab.html",
    function() {
    }
);
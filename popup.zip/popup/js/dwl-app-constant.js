dwlApp.constant('TITLE', 'davask web limited - chrome bookmarker');
dwlApp.constant('AUTHOR', 'david asquiedge');